<?php
namespace App\Dami\SocialPlacesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SocialPlacesBundle extends Bundle
{
    

}

