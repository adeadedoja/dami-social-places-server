<?php

/* contact/contacts.html.twig */
class __TwigTemplate_95c7d230f53990383e2c60035789a025fcb4c64d4d0d8f6cf06567c1442b3cbf extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "contact/contacts.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "contact/contacts.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "contact/contacts.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"contacts__cover pt-4\">
     <h3><b class=\"text-lead\">Submitted</b>Contacts</h3>
     <a class=\"btn btn-primary\" href=\"";
        // line 8
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("new_contact");
        echo "\">Go to contact form <i class=\"fa fa-chevron-right\"></i> </a>
    <div class=\"contacts__container\">
            <div class=\"row\">
                ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contacts"]) || array_key_exists("contacts", $context) ? $context["contacts"] : (function () { throw new Twig_Error_Runtime('Variable "contacts" does not exist.', 11, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["contact"]) {
            echo "   
                    <div class=\"col-md-4\">
                        <div class=\"contacts_card p-4\">                            
                            <div class=\"contact__card__image\">
                                <img src=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/profile-pic.svg"), "html", null, true);
            echo "\" class=\"img-fluid\" alt=\"user image\" />
                            </div>
                            <h4 class=\"text-primary\">";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["contact"], "name", array()), "html", null, true);
            echo "</h4>
                            <p class=\"bold p-0 m-0\"><i class=\"fa fa-envelope-o\"></i> ";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["contact"], "email", array()), "html", null, true);
            echo "</p>
                            <p class=\"bold p-0 m-0\"><i class=\"fa fa-phone\"></i> ";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["contact"], "phone", array()), "html", null, true);
            echo "</p>
                            <hr>
                            <p class=\"text-primary m-0\"><b>Subject: </b>";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["contact"], "subject", array()), "html", null, true);
            echo " </p>
                            <p class=\"my-2\">";
            // line 22
            echo nl2br(twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["contact"], "message", array()), "html", null, true));
            echo "</p>
                            <p class=\"m-0 bold\"><i class=\"fa fa-clock-o\"></i> ";
            // line 23
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["contact"], "createdAt", array()), "date", array()), "F jS \\a\\t g:ia"), "html", null, true);
            echo "</p>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "            </div>
    </div>
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "contact/contacts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 27,  118 => 23,  114 => 22,  110 => 21,  105 => 19,  101 => 18,  97 => 17,  92 => 15,  83 => 11,  77 => 8,  73 => 6,  64 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}{{ title }}!{% endblock %}

{% block body %}
<div class=\"contacts__cover pt-4\">
     <h3><b class=\"text-lead\">Submitted</b>Contacts</h3>
     <a class=\"btn btn-primary\" href=\"{{ path('new_contact') }}\">Go to contact form <i class=\"fa fa-chevron-right\"></i> </a>
    <div class=\"contacts__container\">
            <div class=\"row\">
                {% for contact in contacts %}   
                    <div class=\"col-md-4\">
                        <div class=\"contacts_card p-4\">                            
                            <div class=\"contact__card__image\">
                                <img src=\"{{ asset('images/profile-pic.svg') }}\" class=\"img-fluid\" alt=\"user image\" />
                            </div>
                            <h4 class=\"text-primary\">{{ contact.name }}</h4>
                            <p class=\"bold p-0 m-0\"><i class=\"fa fa-envelope-o\"></i> {{ contact.email }}</p>
                            <p class=\"bold p-0 m-0\"><i class=\"fa fa-phone\"></i> {{ contact.phone }}</p>
                            <hr>
                            <p class=\"text-primary m-0\"><b>Subject: </b>{{ contact.subject }} </p>
                            <p class=\"my-2\">{{ contact.message|nl2br }}</p>
                            <p class=\"m-0 bold\"><i class=\"fa fa-clock-o\"></i> {{ contact.createdAt.date|date(\"F jS \\\\a\\\\t g:ia\") }}</p>
                        </div>
                    </div>
                {% endfor %}
            </div>
    </div>
</div>

{% endblock %}
", "contact/contacts.html.twig", "C:\\wamp\\www\\dami-social-places\\social-places-server\\templates\\contact\\contacts.html.twig");
    }
}
